#pragma once
#include "types.h"
#include <Arduino.h>
#include <Adafruit_NeoPixel.h>

extern LightState    lightState;
extern unsigned long lightStateUntil;
extern bool          lightActive;
extern bool          manualLightActive;
extern bool          stallLightActive;
extern unsigned long stallLightOffTime;
extern bool          ws2812RedActive;

extern bool          dimmingActive;
extern unsigned long dimStartTime;
extern unsigned long dimEndTime;

extern Adafruit_NeoPixel stallLight;

// Laufzeit-Minuten für Stalllicht-Timer (Standard: 1)
extern int stallLightMinutes;

// Locklicht (Relais + WS2812 warm-weiß)
void lightOn();
void lightOff();

// Stalllicht (zweites Relais, Timer-gesteuert)
void stallLightOn();
void stallLightOff();

// WS2812 Testmodus Rot
void ws2812RedOn();
void ws2812RedOff();

// Licht-Zustandsmaschine (einmal pro Loop aufrufen, nach aller Logik)
void updateLightState();

// Timer-Helfer
void startLightForMinutes(int minutes);       // anhängen
void startLightForMinutesReset(int minutes);  // neu starten

// WS2812-Dimming-Update (einmal pro Loop vor updateLightState)
void updateDimming(unsigned long nowMs);

// Stallicht Auto-Aus (einmal pro Loop)
void updateStallLightTimer(unsigned long nowMs);
