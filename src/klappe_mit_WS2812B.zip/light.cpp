#include "light.h"
#include "logger.h"
#include "storage.h"
#include "pins.h"
#include <Arduino.h>

// ==================================================
// GLOBALE VARIABLEN (dieses Moduls)
// ==================================================
LightState    lightState      = LIGHT_OFF;
unsigned long lightStateUntil = 0;
bool          lightActive     = false;
bool          manualLightActive = false;

bool          stallLightActive = false;
unsigned long stallLightOffTime = 0;

bool          ws2812RedActive  = false;

bool          dimmingActive    = false;
unsigned long dimStartTime     = 0;
unsigned long dimEndTime       = 0;

Adafruit_NeoPixel stallLight(WS2812_COUNT, WS2812_PIN, NEO_GRB + NEO_KHZ800);

// ==================================================
// LOCKLICHT
// ==================================================
void lightOn()
{
    digitalWrite(RELAIS_PIN, RELAY_ON);
    for (int i = 0; i < WS2812_COUNT; i++)
        stallLight.setPixelColor(i, stallLight.Color(255, 180, 60));
    stallLight.show();
    Serial.println("💡 LICHT EIN");
}

void lightOff()
{
    digitalWrite(RELAIS_PIN, RELAY_OFF);
    stallLight.clear();
    stallLight.show();
    stallLight.setBrightness(255);
    dimmingActive = false;
    lightState    = LIGHT_OFF;
    Serial.println("💡 LICHT AUS (Relais + WS2812)");
}

// ==================================================
// STALLLICHT
// ==================================================
void stallLightOn()
{
    stallLightActive   = true;
    stallLightOffTime  = millis() + (unsigned long)stallLightMinutes * 60000UL;
    digitalWrite(STALLLIGHT_RELAY_PIN, RELAY_ON);
    addLog("Stalllicht angeschaltet");
}

void stallLightOff()
{
    stallLightActive = false;
    digitalWrite(STALLLIGHT_RELAY_PIN, RELAY_OFF);
    addLog("Stalllicht ausgeschaltet");
}

// ==================================================
// WS2812 ROT
// ==================================================
void ws2812RedOn()
{
    ws2812RedActive = true;
    stallLight.clear();
    stallLight.setBrightness(255);
    for (int i = 0; i < WS2812_COUNT; i++)
        stallLight.setPixelColor(i, 255, 0, 0);
    stallLight.show();
    Serial.println("🔴 WS2812 Rot EIN");
    addLog("🔴 Rotlicht EIN");
}

void ws2812RedOff()
{
    ws2812RedActive = false;
    stallLight.clear();
    stallLight.show();
    Serial.println("⚫ WS2812 Rot AUS");
    addLog("🔴 Rotlicht AUS");
}

// ==================================================
// TIMER-HELFER
// ==================================================
void startLightForMinutes(int minutes)
{
    unsigned long addMs = (minutes <= 0) ? 10000UL : (unsigned long)minutes * 60000UL;
    unsigned long nowMs = millis();
    if (lightStateUntil > nowMs) lightStateUntil += addMs;
    else                         lightStateUntil  = nowMs + addMs;
}

void startLightForMinutesReset(int minutes)
{
    unsigned long addMs = (minutes <= 0) ? 10000UL : (unsigned long)minutes * 60000UL;
    lightStateUntil = millis() + addMs;
}

// ==================================================
// LICHT-ZUSTANDSMASCHINE
// ==================================================
void updateLightState()
{
    if (ws2812RedActive)   return;
    if (manualLightActive) return;

    unsigned long nowMs = millis();

    switch (lightState)
    {
    case LIGHT_OFF:
        if (lightActive) { lightOff(); lightActive = false; }
        break;

    case LIGHT_PRE_OPEN:
    case LIGHT_POST_OPEN:
    case LIGHT_PRE_CLOSE:
    case LIGHT_POST_CLOSE:
        if (!lightActive) { lightOn(); lightActive = true; }
        if (nowMs >= lightStateUntil)
        {
            if (lightState == LIGHT_POST_OPEN)  addLog("Locklicht nach Öffnung beendet");
            if (lightState == LIGHT_POST_CLOSE) addLog("Locklicht nach Schließen beendet");
            lightState = LIGHT_OFF;
        }
        break;
    }
}

// ==================================================
// DIMMING UPDATE
// ==================================================
void updateDimming(unsigned long nowMs)
{
    if (!dimmingActive || !lightActive) return;
    if (nowMs >= dimStartTime && nowMs <= dimEndTime)
    {
        float progress  = float(nowMs - dimStartTime) / float(dimEndTime - dimStartTime);
        progress        = constrain(progress, 0.0f, 1.0f);
        int brightness  = constrain(int(255 * (1.0f - progress)), 0, 255);
        stallLight.setBrightness(brightness);
        for (int i = 0; i < WS2812_COUNT; i++)
            stallLight.setPixelColor(i, stallLight.Color(255, 180, 60));
        stallLight.show();
    }
    if (nowMs > dimEndTime) dimmingActive = false;
}

// ==================================================
// STALLLICHT AUTO-AUS
// ==================================================
void updateStallLightTimer(unsigned long nowMs)
{
    if (stallLightActive && nowMs >= stallLightOffTime)
        stallLightOff();
}
